# THIS FILE IS AUTO-GENERATED. PLEASE DO NOT MODIFY# version file for python3-ldap
# generated on 2015-05-28 06:37:09.983371
# on system uname_result(system='Windows', node='GCNBHPW8', release='8', version='6.2.9200', machine='AMD64', processor='Intel64 Family 6 Model 58 Stepping 9, GenuineIntel')
# with Python 3.4.3 - ('v3.4.3:9b73f1c3e601', 'Feb 24 2015 22:44:40') - MSC v.1600 64 bit (AMD64)
#
__version__ = '0.9.8.4'
__author__ = 'Giovanni Cannata'
__email__ = 'cannatag@gmail.com'
__url__ = 'https://github.com/cannatag/ldap3'
__description__ = 'A strictly RFC 4511 conforming LDAP V3 pure Python client. Same codebase for Python 2, Python3, PyPy and PyPy 3'
__status__ = 'development - beta'
__license__ = 'LGPL v3'